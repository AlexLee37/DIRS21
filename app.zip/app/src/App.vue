<template>
  <div class="app">
    <form @submit.prevent>
      <h4>Change Menu</h4>
      <input v-bind:value="title" @input="title = $event.target.value" class="input-text" type="text"
        placeholder="Title">
      <input v-bind:value="description" @input="description = $event.target.value" class="input-text" type="text"
        placeholder="Description">
      <input v-bind:value="price" @input="price = $event.target.value" class="input-text" type="text"
        placeholder="Price">
      <input v-bind:value="category" @input="category = $event.target.value" class="input-text" type="text"
        placeholder="Category">
      <input v-bind:value="waiting_time" @input="waiting_time = $event.target.value" class="input-text" type="text"
        placeholder="Waiting time">
      <div>
        <button class="btn" @click="createMenu">Add dish</button>
        <button class="btn" @click="saveChanges">Save changes</button>
      </div>
    </form>
    <div class="menu" v-for="(menu, i) in menus" :key="i">
      <div><strong>Title: </strong>{{ menu.title }}</div>
      <div><strong>Description: </strong>{{menu.description}}</div>
      <div><strong>Price: </strong>{{menu.price}}</div>
      <div><strong>Category: </strong>{{menu.category}}</div>
      <div><strong>Waiting time: </strong>{{menu.waiting_time}}</div>
      <div><button class="btn" @click="deleteMenu(i)">Delete</button></div>
      <div><button class="btn" @click="editMenu(i)">Edit</button></div>
    </div>
  </div>
</template>

<script>


export default {
  data() {
    return {
      menus: [
      ],
      title: '',
      description: '',
      price: '',
      category: '',
      waiting_time: '',
    }
  },
  methods: {
    createMenu() {
      const newDish = {
        id: Date.now(),
        title: this.title,
        description: this.description,
        price: this.price,
        category: this.category,
        waiting_time: this.waiting_time,
      }
      this.menus.push(newDish);
      this.title = '';
      this.description = '';
      this.price = '';
      this.category = '';
      this.waiting_time = '';
    },
    deleteMenu(i) {
      this.menus.splice(i, 1);
    },
    editMenu(i) {
      this.title = this.menus[i].title;
      this.description = this.menus[i].description;
      this.price = this.menus[i].price;
      this.category = this.menus[i].category;
      this.waiting_time = this.menus[i].waiting_time;
    },
    saveChanges(i) {
      const editDish = {
        id: Date.now(),
        title: this.title,
        description: this.description,
        price: this.price,
        category: this.category,
        waiting_time: this.waiting_time,
      }
      this.menus.splice(i, 1, editDish);
      this.title = '';
      this.description = '';
      this.price = '';
      this.category = '';
      this.waiting_time = '';
    }
  }
}

</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.app {
  padding: 20px;
}

.menu {
  padding: 15px;
  border: 2px solid teal;
  margin-top: 15px;
}

form {
  display: flex;
  flex-direction: column;
}

.input-text {
  width: 100%;
  border: 1px solid teal;
  padding: 10px 15px;
  margin-top: 15px;
}

.btn {
  margin-top: 15px;
  margin-right: 15px;
  padding: 10px 15px;
  background: none;
  color: teal;
  border: 1px solid teal;
  display: inline-block;
  width: 150px;
}


</style>